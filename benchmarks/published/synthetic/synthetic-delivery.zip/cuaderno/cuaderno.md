# Cuaderno del agente — hipotesis-8T69

- Receptor: 8T69
- Aprobado: 2026-11-04T04:15:09+00:00
- Terminó: 2026-11-04T04:15:09+00:00
- Huella del plan: `sha256:78f04555bdca5759fe6fd06f4456ee936c5c4432e9c87ee0c7bee81b23cd80f8`

## Lo que se pidió

molchat investiga esta lista de moléculas y si alguna pasa el umbral de -9.0 kcal/mol la guardas en moldex, generas un vídeo de búsqueda, le haces la auditoría en preparación y al final me preparas todo en un único archivo

## Lo que se aprobó

- Caso «hipotesis-8T69» · receptor 8T69
- 3 moléculas, una tras otra en este mismo caso: Rota, Buena, Nunca
- Se detiene en la primera que cumple: Vina ≤ -9 kcal/mol y controles físicos de la mejor pose superados
- Si una molécula falla, se anota y se sigue con la siguiente.
- La que cumpla se guarda en Moldex.
- Vídeo de Molcy (solo GPU): escena búsqueda, formato horizontal; el cierre de MolDesign se añade siempre.
- Presentación: la automática de Molcy.
- Se audita la corrida en Preparación; si queda en revisión, se declara, no se decide.
- Al final se junta todo en un único ZIP.
- Tope: 7 min por molécula y 40 min en total.

## Qué ocurrió

Terminó: hay una molécula que cumple la regla.

| # | Molécula | Estado | Vina (kcal/mol) | Controles físicos | Lectura |
|---|---|---|---|---|---|
| 1 | Rota | falló | — | — | No se cargó la molécula en el caso («failed»). |
| 2 | Buena | evaluada | -9.483 | passed | cumple la regla |
| 3 | Nunca | no se evaluó | — | — | Ya se cumplió la regla de parada. |

- Molécula 1 (Rota): No se cargó la molécula en el caso («failed»).
- Molécula 3 (Nunca): Ya se cumplió la regla de parada.

### Tiempos medidos

Espera del caso: hasta que la ventana dijo que la corrida anterior había cerrado. Resultado: desde que arrancó la corrida hasta que el backend la dio por terminada con su energía.

- Molécula 1 (Rota): espera del caso 0 s («idle»), arranque —, resultado —, total 0 s.
- Molécula 2 (Buena): espera del caso 0 s («idle»), arranque 0 s, resultado 0 s, total 0 s.

## Condiciones de las corridas

Sobre las 1 corridas evaluadas:
- Iguales en todas: versión de Vina 1.2.7.
- Sin registrar en alguna corrida: receptor preparado, motor, exhaustividad, poses, semilla, centro de la caja, tamaño de la caja; no se da por igual.

## Registro por molécula

Lo que MolDesign registró de cada corrida y de dónde salió cada SMILES, tal cual; nada se interpreta aquí.

### 1. Rota

- SMILES del plan: `C1CC`
- Procedencia: no registrada (el SMILES no coincide literalmente con ninguna consulta de PubChem de esta conversación).

### 2. Buena

- SMILES del plan: `CCN`
- Procedencia: no registrada (el SMILES no coincide literalmente con ninguna consulta de PubChem de esta conversación).
- Avisos de la corrida: no registrados.
- Tarea: t-8t69

### 3. Nunca

- SMILES del plan: `CCO`
- Procedencia: no registrada (el SMILES no coincide literalmente con ninguna consulta de PubChem de esta conversación).

## Lo que se hizo con la elegida

Buena (tarea t-8t69): Vina -9.483 kcal/mol, controles físicos passed.
- Moldex: saved · message: Corrida guardada en Moldex.
- Vídeo de Molcy: started · message: Vídeo en cola en Molcy (lanzado desde su pestaña). · job_id: 11111111-2222-4333-8444-555555555555 · file: molcy_11111111.mp4
- Preparación: unavailable · message: Esta versión de MolDesign no permite auditar en Preparación desde el chat.
- Entrega: building · message: Este cuaderno forma parte de la entrega.

## Límites y procedencia

La energía de Vina es la de la mejor pose según Vina: no es una energía libre, ni un Ki, ni una medida de actividad. Una iteración sobre pocas moléculas no ordena fármacos. Los controles físicos son los de PoseBusters tal como los declara MolDesign.

Las energías, los controles físicos, el protocolo, los avisos y la especie acoplada los dio MolDesign; la identidad de cada molécula, la consulta de PubChem de esta conversación cuyo SMILES coincide literalmente. MolChat ordenó las llamadas, anotó lo ocurrido y escribió este cuaderno sin intervención del modelo.
