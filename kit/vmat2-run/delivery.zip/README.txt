MolChat delivery
================

This ZIP gathers what an approved plan produced. Nothing in it was made up by the model.

notebook/      What was asked, what was approved and what happened to each molecule (written by MolChat, not the model).
preparation/   The Preparation package EXACTLY as MolDesign delivered it, unopened and unchanged (its hash is in MANIFEST.json).
video/         The video Molcy rendered in MolDesign, with its closing.
MANIFEST.json  Every piece with its SHA-256, who produced it, and what is missing with the reason.

How to check it: compute the SHA-256 of each file and compare it with MANIFEST.json.
The Vina energy is not a free energy nor a measure of activity.
